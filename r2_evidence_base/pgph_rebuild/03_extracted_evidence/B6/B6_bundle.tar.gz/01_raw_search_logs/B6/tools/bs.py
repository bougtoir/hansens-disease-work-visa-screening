import sys, json
from lib import search
for line in open(sys.argv[1]):
    if not line.strip(): continue
    j,st,lg,q = line.rstrip('\n').split('\t')
    print('\n###', j, st, q)
    try: search(j,st,lg,q,8)
    except Exception as e: print('ERR', e)
