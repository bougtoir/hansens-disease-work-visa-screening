import sys
from lib import fetch
for line in open(sys.argv[1]):
    if not line.strip(): continue
    p=line.rstrip('\n').split('\t'); iso,short,url=p[:3]; mode=p[3] if len(p)>3 else 'curl'; w=int(p[4]) if len(p)>4 else 5
    try:
        fn=fetch(iso,short,url,mode,w); print(fn.name, fn.stat().st_size, flush=True)
    except Exception as e: print('ERR',iso,short,e, flush=True)
