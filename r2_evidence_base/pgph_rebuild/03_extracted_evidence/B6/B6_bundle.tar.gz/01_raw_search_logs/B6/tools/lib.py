import asyncio, sys, json, urllib.parse, hashlib, datetime, os, subprocess, re
from pathlib import Path
RB = Path.home()/'repos/wip/scoping-review-hansens-disease/pgph_rebuild'
LOG = RB/'01_raw_search_logs/B6'; SRC = RB/'02_primary_sources/B6'
def now(): return datetime.datetime.now(datetime.timezone.utc)
def ts(): return now().strftime('%Y%m%dT%H%M%SZ')
async def _search(q):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.connect_over_cdp('http://localhost:29229')
        pg = await b.contexts[0].new_page()
        await pg.goto('https://duckduckgo.com/?kl=wt-wt&q='+urllib.parse.quote(q), timeout=45000); await pg.wait_for_timeout(3000)
        res = await pg.evaluate('''()=>Array.from(document.querySelectorAll('article[data-testid=result]')).map(a=>{const l=a.querySelector('a[data-testid=result-title-a]');const s=a.querySelector('[data-result=snippet]');return [l?l.href:'',l?l.innerText:'',s?s.innerText:'']})''')
        html = await pg.content(); await pg.close(); return res, html
def search(jid, stage, lang, q, n=10):
    t = ts(); res, html = asyncio.run(_search(q))
    fn = LOG/f"{jid[2:]}_ddg_{t}.html"; fn.write_text(html)
    rec = dict(jid=jid, stage=stage, lang=lang, t=now().isoformat(timespec='seconds'), q=q, engine='DuckDuckGo (Chrome CDP)', results=res[:n], raw=str(fn.relative_to(RB.parent)))
    with open(LOG/'queries.jsonl','a') as f: f.write(json.dumps(rec, ensure_ascii=False)+'\n')
    for i,(u,ti,s) in enumerate(res[:n]): print(i, u, '|', ti[:90], '|', s[:200].replace('\n',' '))
async def _cfetch(url, wait):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.connect_over_cdp('http://localhost:29229')
        pg = await b.contexts[0].new_page()
        try:
            async with pg.expect_download(timeout=wait*1000+20000) as dl:
                try: await pg.goto(url, timeout=60000)
                except Exception as e:
                    if 'Download is starting' not in str(e): raise
            d = await dl.value; path = await d.path(); data = open(path,'rb').read(); await pg.close(); return data, 'download'
        except Exception as e:
            if 'Timeout' not in str(e) and 'download' not in str(e).lower(): pass
        await pg.wait_for_timeout(wait*1000)
        try: html = await pg.content()
        except Exception: html=''
        await pg.close(); return html.encode(), 'html'
def fetch(iso, short, url, mode='curl', wait=4):
    t = ts()
    if mode=='curl':
        r = subprocess.run(['curl','-sL','-m','90','-A','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120 Safari/537.36','-w','\n__HTTP__%{http_code}__%{content_type}',url],capture_output=True)
        out = r.stdout; i = out.rfind(b'\n__HTTP__'); meta = out[i:].decode(errors='ignore'); data = out[:i]
        code = meta.split('__')[2] if '__' in meta else '?'; ct = meta.split('__')[3] if meta.count('__')>=3 else ''
    else:
        data, ct = asyncio.run(_cfetch(url, wait)); code='chrome'
    ext = 'pdf' if data[:4]==b'%PDF' else ('html' if b'<' in data[:2000] else 'txt')
    if data[:2]==b'PK': ext='zip'
    fn = SRC/f"{iso}_{short}_{t}.{ext}"; fn.write_bytes(data)
    sha = hashlib.sha256(data).hexdigest()
    rec = dict(iso=iso, short=short, url=url, t=now().isoformat(timespec='seconds'), path=str(fn.relative_to(RB.parent)), bytes=len(data), sha256=sha, http=code, mode=mode)
    with open(LOG/'fetches.jsonl','a') as f: f.write(json.dumps(rec)+'\n')
    print(json.dumps(rec)); return fn
def text(fn):
    fn = Path(fn)
    if fn.suffix=='.pdf': return subprocess.run(['pdftotext','-layout',str(fn),'-'],capture_output=True,text=True).stdout
    from bs4 import BeautifulSoup
    b=fn.read_bytes()
    try: b=b.decode('utf-8')
    except Exception: pass
    return BeautifulSoup(b,'html.parser').get_text('\n')
def grep(fn, pat, ctx=300, maxn=20):
    t = text(fn); n=0
    for m in re.finditer(pat, t, re.I):
        print('...', re.sub(r'\s+',' ',t[max(0,m.start()-ctx):m.end()+ctx]), '...\n'); n+=1
        if n>=maxn: break
    print('hits', n, 'len', len(t))
if __name__=='__main__':
    cmd=sys.argv[1]
    if cmd=='s': search(*sys.argv[2:6])
    elif cmd=='f': fetch(*sys.argv[2:5], *(sys.argv[5:6] or []), *( [int(sys.argv[6])] if len(sys.argv)>6 else []))
    elif cmd=='g': grep(sys.argv[2], sys.argv[3], int(sys.argv[4]) if len(sys.argv)>4 else 300)
    elif cmd=='t': print(text(sys.argv[2])[:int(sys.argv[3]) if len(sys.argv)>3 else 5000])
