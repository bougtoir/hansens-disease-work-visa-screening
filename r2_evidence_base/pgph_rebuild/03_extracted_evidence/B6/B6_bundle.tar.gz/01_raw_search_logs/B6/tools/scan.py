import lib,re,sys
from pathlib import Path
pat=re.compile(r'lepr|lèpre|hansen|holdsveik|spedalsk|raups|leepra|spitál', re.I)
tb=re.compile(r'tuberk|tubercul|tbc|berkl', re.I)
for f in sorted(lib.SRC.iterdir()):
    if len(sys.argv)>1 and not any(f.name.startswith(a) for a in sys.argv[1:]): continue
    try: t=lib.text(f)
    except Exception as e: t=''
    t=re.sub(r'\s+',' ',t)
    hs=[t[max(0,m.start()-80):m.end()+80] for m in pat.finditer(t)][:2]
    print(f.name, len(t), 'HD',len(pat.findall(t)),'TB',len(tb.findall(t)), '|'.join(hs)[:400])
