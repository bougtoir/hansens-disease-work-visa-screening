"""Build B7 extraction tables from saved sources + coding (b7_sources.py, b7_coding.py). Verifies every quoted wording against saved text."""
import csv, json, hashlib, re, sys, subprocess, datetime, collections
from pathlib import Path
T = Path(__file__).resolve().parent; LOG = T.parent; RB = LOG.parents[1]; PROJ = RB.parent
sys.path.insert(0, str(RB / "data")); sys.path.insert(0, str(T))
import schema as S; from b7_sources import M; import b7_coding as C
SRC = RB / "02_primary_sources/B7"; OUT = RB / "03_extracted_evidence/B7"; OUT.mkdir(parents=True, exist_ok=True)
DER = LOG / "derived"; DER.mkdir(exist_ok=True)
NOW = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
frame = {r["jurisdiction_id"]: r for r in csv.DictReader(open(RB / "data/JURISDICTION_FRAME.csv"))}
JIDS = sorted(j for j, r in frame.items() if r["search_batch"].split()[0] == "B7")
# ---- ledger
led = {}
for l in open(LOG / "fetch_ledger.jsonl"):
    r = json.loads(l)
    if r.get("local_path"): led[Path(r["local_path"]).name] = r
for r in csv.DictReader(open(PROJ / "data/raw/primary_sources/FETCH_LOG.csv")):
    nm = Path(r["path"]).name
    if (SRC / nm).exists(): led[nm] = dict(url=r["url"], retrieved_utc=r["retrieved_utc"], mode="copied from data/raw/primary_sources (pre-rebuild snapshot)", http_status=r["http_status"])
def stem_key(fn):
    s = re.sub(r"_\d{8}T\d{6}Z\.[A-Za-z0-9]+$", "", fn); return s
files = sorted(p for p in SRC.iterdir() if p.is_file() and not p.name.endswith(".tar.gz"))
key2file = {}; reg = []
for p in files:
    k = stem_key(p.name)
    if k not in M: sys.exit(f"no metadata for {p.name}")
    j, title, auth, tier, dtype, lang, eff, status, notes = M[k]
    lr = led.get(p.name, {})
    b = p.read_bytes(); sid = "B7S-" + k
    key2file[k] = p
    reg.append(dict(source_id=sid, jurisdiction_id=j, title=title, issuing_authority=auth, source_tier=tier, doc_type=dtype, language=lang, url=lr.get("url", ""),
        archive_url="", retrieved_utc=lr.get("retrieved_utc", ""), local_path=str(p.relative_to(PROJ)), bytes=len(b), sha256=hashlib.sha256(b).hexdigest(),
        effective_date=eff, status_in_force=status, redistribution="public official/legal text; stored for research verification (check host terms before redistribution)",
        notes="; ".join(x for x in [notes, f"fetch mode: {lr.get('mode','')}"] if x)))
missing_meta = set(M) - set(key2file)
regd = {r["source_id"]: r for r in reg}
# ---- text for verification
def norm(s): return re.sub(r"\s+", " ", s.replace("\u00ad", "")).strip()
def texts(k):
    p = key2file[k]; out = []
    for c in [LOG / "text" / (p.stem + ".txt")]:
        if c.exists(): out.append(c.read_text(errors="ignore"))
    if p.suffix == ".pdf":
        d = DER / (p.stem + ".raw.txt")
        if not d.exists(): subprocess.run(["pdftotext", str(p), str(d)])
        if d.exists(): out.append(d.read_text(errors="ignore"))
    if p.suffix in (".html",) and not out:
        from bs4 import BeautifulSoup
        out.append(BeautifulSoup(p.read_bytes(), "html.parser").get_text("\n"))
    res = []
    for t in out: res += [norm(t), norm(re.sub(r"-\s*\n\s*", "", t))]
    return res
bad = []; ev = []
for i, e in enumerate(C.EV, 1):
    v = e["verify"]
    if v and v.startswith("derived/"): tx = [norm((LOG / v).read_text(errors="ignore"))]
    else: tx = texts(v or e["src"])
    if not any(norm(e["source_wording_original"]) in t for t in tx): bad.append((e["src"], e["source_wording_original"][:80]))
    sid = "B7S-" + e["src"]
    row = {k: e.get(k, "") for k in S.EVIDENCE_ROWS}
    row.update(evidence_id=f"B7-E{i:03d}", source_id=sid, evidence_tier=regd[sid]["source_tier"], reviewer="Devin (B7 batch agent)", record_created_at=NOW,
               excerpt_locator=e["excerpt_locator"] or regd[sid]["local_path"])
    if v and not v.startswith("derived/"): row["classification_note"] = (row["classification_note"] + f"; wording verified in {('B7S-'+v)}").strip("; ")
    if v and v.startswith("derived/"): row["classification_note"] = (row["classification_note"] + f"; wording verified in derived text {v}").strip("; ")
    ev.append(row)
if bad:
    print("QUOTE VERIFICATION FAILURES:"); [print(" ", b) for b in bad]; sys.exit(2)
# ---- pathways
pw_rows = []
for pid, p in C.PW.items():
    r = {k: p.get(k, "") for k in S.POLICY_PATHWAYS}; r["pathway_id"] = pid
    r["governing_source_ids"] = ";".join("B7S-" + s for s in p["srcs"]); pw_rows.append(r)
    for s in p["srcs"]: assert "B7S-" + s in regd, (pid, s)
cl_rows = []; sf_rows = []; pt_rows = []
for pid, p in C.PW.items():
    c = C.CLIN.get(pid, {}); srcs = ";".join("B7S-" + s for s in p["srcs"])
    cl_rows.append(dict(jurisdiction_id=p["jurisdiction_id"], pathway_id=pid, **{k: c.get(k, "not_addressed") for k in ["active_untreated", "on_treatment", "mdt_completed", "cured", "residual_sequelae"]}, source_ids=srcs, notes=c.get("notes", "")))
    s = C.SAFE.get(pid, {})
    sf_rows.append(dict(jurisdiction_id=p["jurisdiction_id"], pathway_id=pid, **{k: s.get(k, "no_statement_located") for k in ["discretion", "individual_assessment", "retest", "waiver", "appeal_review"]}, source_ids=srcs, notes=s.get("notes", "")))
    if pid in C.POST: rs, mech, ps, nt = C.POST[pid]; ps = ";".join("B7S-" + x for x in ps)
    elif p["hd_named_status"] == "not_established": rs, mech, ps, nt = "not_applicable_hd_not_named", "", srcs, "HD not named in reviewed pathway sources"
    else: rs, mech, ps, nt = "cannot_determine", "", srcs, "HD status cannot be determined (DSS unresolved or list content not retrieved)"
    pt_rows.append(dict(jurisdiction_id=p["jurisdiction_id"], pathway_id=pid, risk_status=rs, mechanism=mech, source_ids=ps, notes=nt))
tr_rows = [dict(jurisdiction_id=C.PW[pid]["jurisdiction_id"], pathway_id=pid, trigger_type=t, trigger_value=v, source_ids=";".join("B7S-" + x for x in s), notes=n) for pid, t, v, s, n in C.TRIG]
den_rows = []
# ---- search log
stg = [json.loads(l) for l in open(LOG / "search_staging.jsonl")]
ledurls = {r.get("url") for r in led.values()}
sl = []
for q in stg:
    if q["search_id"] == "Q-B7-0046": q = dict(q, language="en", _n="logged as mt (Malta); query text is English (official language)")
    raw = (LOG / "raw" / f"{q['search_id']}.md").read_text(errors="ignore")
    hits = re.findall(r"## \d+\. (.*)\nURL: (\S+)", raw)
    opened = [u for _, u in hits if u in ledurls]
    sl.append(dict(search_id=q["search_id"], jurisdiction_id=q["jurisdiction_id"], batch="B7", stage=q["stage"], language=q["language"], timestamp_utc=q["timestamp_utc"],
        query=q["query"], engine_or_database="Devin web_search (general web)", result_url=hits[0][1] if hits else "", hit_title=hits[0][0][:200] if hits else "",
        relevant_excerpt="", opened_full_text="yes" if opened else "no", access_status=q.get("access", "ok") if hits else "no_results",
        translation_method="query authored in local language by agent" if q["stage"] != "P1_english" else "n/a",
        notes=(q.get("_n","") + "; " if q.get("_n") else "") + f"full hit list: 01_raw_search_logs/B7/raw/{q['search_id']}.md; hits={len(hits)}" + (f"; fetched from hits: {len(opened)}" if opened else "")))
# ---- jurisdiction status
TIER = {f"S{i}": i for i in range(1, 8)}
EXT = {"J-RUS": "extended: HD-specific evidence (official scanned PDF read page-by-page)", "J-HRV": "extended: imported leprosy case notice + new 2026 decision", "J-HUN": "extended: historical (114/2007, Act II 2007) vs current (Act XC 2023) conflict", "J-CZE": "extended: repealed 274/2004 list vs current conditional measure", "J-GRC": "extended: 2010/2012 circulars (old law) vs Law 5038/2023", "J-MLT": "extended: Cap. 36 leprosy listing applicability check"}
UNRES = {"J-ALB": "generic grounds only; implementing list not located", "J-AND": "delegated disease list (regulation 2010) not retrievable", "J-BGR": "Ministry of Health criteria not retrieved", "J-BIH": "certificate content generic; no list", "J-BLR": "MoH disease list PDF timed out", "J-CZE": "current MoH measure not established", "J-GRC": "current exam content unspecified; historical TB tests", "J-MKD": "generic definition only", "J-MNE": "official sources timed out", "J-POL": "delegated MoH disease-list regulation not retrievable", "J-PRT": "generic grounds; exam content unspecified", "J-ROU": "OUG 194/2002 & visa pages 403", "J-SVK": "medical report content (decree 38/2011) not retrieved", "J-SVN": "ZTuj-2 text not rendered", "J-UKR": "no medical rule located; law text timed out", "J-VAT": "no labour-migration pathway identified", "J-XKX": "generic grounds; sub-legal acts not retrieved"}
js = []
for j in JIDS:
    qs = [q for q in stg if q["jurisdiction_id"] == j]
    srcs = [r for r in reg if r["jurisdiction_id"] == j]
    pws = [p for pid, p in C.PW.items() if p["jurisdiction_id"] == j]
    main = sorted(pws, key=lambda p: (p["pathway_type"] == "P3_other"))[0] if pws else None
    js.append(dict(jurisdiction_id=j, batch="B7", english_pass_done="yes" if any(q["stage"] == "P1_english" for q in qs) else "no",
        local_pass_done="yes" if any(q["stage"] == "P2_local" for q in qs) else "no",
        local_languages_used=";".join(sorted({q["language"] for q in qs if q["stage"] != "P1_english"})), n_queries=len(qs), n_sources_opened=len(srcs),
        best_source_tier=min((r["source_tier"] for r in srcs), key=lambda t: TIER[t]) if srcs else "S7",
        dss_status=main["dss_status"] if main else "unresolved", hd_named_status=main["hd_named_status"] if main else "cannot_determine",
        unresolved_reason=UNRES.get(j, "") if (main is None or main["dss_status"] == "unresolved") else "", hours_spent="",
        notes="; ".join(x for x in [EXT.get(j, ""), "hours not tracked (time budget ~10-20 min/jurisdiction applied)"] if x)))
# ---- write
def W(name, rows):
    with open(OUT / f"{name}.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=S.TABLES[name]); w.writeheader(); [w.writerow({k: r.get(k, "") for k in S.TABLES[name]}) for r in rows]
W("SEARCH_LOG", sl); W("SOURCE_REGISTER", reg); W("EVIDENCE_ROWS", ev); W("POLICY_PATHWAYS", pw_rows); W("CLINICAL_STATUS_RULES", cl_rows); W("SAFEGUARDS", sf_rows)
W("NATIONALITY_ORIGIN_TRIGGERS", tr_rows); W("OBSERVED_DENIALS", den_rows); W("POST_TREATMENT_RISK", pt_rows); W("JURISDICTION_STATUS", js)
summary = dict(n_queries=len(sl), n_sources=len(reg), n_evidence=len(ev), n_pathways=len(pw_rows), missing_meta=sorted(missing_meta),
    dss={s: [r["jurisdiction_id"] for r in js if r["dss_status"] == s] for s in S.ENUMS["dss_status"]},
    hd={s: [r["jurisdiction_id"] for r in js if r["hd_named_status"] == s] for s in S.ENUMS["hd_named_status"]},
    post={s: sorted({r["jurisdiction_id"] for r in pt_rows if r["risk_status"] == s}) for s in S.ENUMS["risk_status"]})
json.dump(summary, open(LOG / "build_summary.json", "w"), indent=1, ensure_ascii=False); print(json.dumps(summary, ensure_ascii=False))
