"""print matches with nearest preceding 'Article/Neni/Член/Čl./§' heading. usage: ctx.py file regex [width]"""
import re,sys
f,rx=sys.argv[1],sys.argv[2]; w=int(sys.argv[3]) if len(sys.argv)>3 else 2
L=open(f,errors="replace").read().splitlines(); head=""
H=re.compile(r"^\s*(Article|Art\.|Artículo|Articolo|Artigo|Article|Neni|Член|Чл\.|Člen|Članak|Član|Čl\.|§|Статья|Стаття|Articolul|Art|Αρθρο|Άρθρο|Paragraf)\s*\d",re.I)
for i,l in enumerate(L):
    if H.match(l): head=l.strip()[:60]
    if re.search(rx,l,re.I):
        print(f"--- L{i+1} [{head}]"); print("\n".join(x.rstrip() for x in L[max(0,i-w):i+w+1]))
