"""B7 fetch helper: save raw source bytes to 02_primary_sources/B7 and append a ledger line.
Usage: python3 fetch.py ISO3 SHORT URL [curl|cdp|cdpraw]   (cdp = rendered DOM via local Chrome; cdpraw = raw bytes via Chrome request)"""
import sys, json, hashlib, datetime, subprocess, asyncio
from pathlib import Path
RB = Path(__file__).resolve().parents[3]
DEST = RB / "02_primary_sources" / "B7"; LEDGER = RB / "01_raw_search_logs" / "B7" / "fetch_ledger.jsonl"
iso, short, url = sys.argv[1:4]; mode = sys.argv[4] if len(sys.argv) > 4 else "curl"
stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
status, ctype, body, err = "", "", b"", ""
if mode == "curl":
    p = subprocess.run(["curl", "-sSL", "-m", "90", "-A", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36",
                        "-w", "\n__META__%{http_code}|%{content_type}", url], capture_output=True)
    out = p.stdout; i = out.rfind(b"\n__META__")
    if i >= 0:
        body = out[:i]; status, ctype = out[i + 9:].decode(errors="replace").split("|", 1)
    err = p.stderr.decode(errors="replace")[:200]
else:
    from playwright.async_api import async_playwright
    async def go():
        async with async_playwright() as pw:
            b = await pw.chromium.connect_over_cdp("http://localhost:29229"); ctx = b.contexts[0]
            if mode == "cdpraw":
                r = await ctx.request.get(url, timeout=90000, ignore_https_errors=True)
                return await r.body(), str(r.status), r.headers.get("content-type", "")
            pg = await ctx.new_page()
            try:
                r = await pg.goto(url, timeout=90000, wait_until="domcontentloaded"); await pg.wait_for_timeout(8000)
                return (await pg.content()).encode(), str(r.status if r else 0), "text/html(rendered DOM)"
            finally:
                await pg.close()
    try:
        body, status, ctype = asyncio.run(go())
    except Exception as e:
        err = repr(e)[:200]
ext = ".pdf" if body[:4] == b"%PDF" else (".docx" if body[:2] == b"PK" else ".html")
rec = dict(iso3=iso, short=short, url=url, mode=mode, retrieved_utc=stamp, http_status=status, content_type=ctype, error=err, bytes=len(body))
if body and len(body) > 200 and not str(status).startswith(("4","5")):
    f = DEST / f"{iso}_{short}_{stamp}{ext}"; f.write_bytes(body)
    rec.update(local_path=str(f.relative_to(RB.parent)), sha256=hashlib.sha256(body).hexdigest())
    if ext == ".pdf":
        t = subprocess.run(["pdftotext", "-layout", str(f), "-"], capture_output=True).stdout
        (RB / "01_raw_search_logs/B7/text" ).mkdir(exist_ok=True); (RB / "01_raw_search_logs/B7/text" / (f.stem + ".txt")).write_bytes(t)
    else:
        from bs4 import BeautifulSoup
        t = BeautifulSoup(body, "html.parser").get_text("\n")
        (RB / "01_raw_search_logs/B7/text").mkdir(exist_ok=True); (RB / "01_raw_search_logs/B7/text" / (f.stem + ".txt")).write_text(t)
with open(LEDGER, "a") as fh: fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
print(json.dumps({k: rec.get(k) for k in ("short", "http_status", "bytes", "local_path", "error")}, ensure_ascii=False))
