import csv, json, collections
from pathlib import Path
T = Path(__file__).resolve().parent; LOG = T.parent; RB = LOG.parents[1]; OUT = RB / "03_extracted_evidence/B7"
S = json.load(open(LOG / "build_summary.json"))
R = lambda n: list(csv.DictReader(open(OUT / f"{n}.csv", encoding="utf-8")))
js, pw, ev, sr, sl = R("JURISDICTION_STATUS"), R("POLICY_PATHWAYS"), R("EVIDENCE_ROWS"), R("SOURCE_REGISTER"), R("SEARCH_LOG")
stages = collections.Counter(r["stage"] for r in sl); tiers = collections.Counter(r["source_tier"] for r in sr)
inacc = (LOG / "inaccessible_sources.txt").read_text().splitlines()
L = ["# B7 batch report — Europe (South/East), 26 jurisdictions", "",
"Evidence-first rebuild. Classification uses only saved, re-read sources (02_primary_sources/B7). Search snippets were never used for classification; failed retrievals are 'unresolved'. Historical aggregate counts were not used.", "",
"## Counts", f"- Queries run: {S['n_queries']} (" + ", ".join(f"{k} {v}" for k, v in sorted(stages.items())) + ") — engine: Devin web_search; full hit lists in 01_raw_search_logs/B7/raw/",
f"- Sources saved and registered: {S['n_sources']} (" + ", ".join(f"{k} {v}" for k, v in sorted(tiers.items())) + ") with SHA-256 and UTC retrieval time",
f"- Evidence rows: {S['n_evidence']} (all quoted wording machine-verified against saved text by tools/build_tables.py, except where noted)", f"- Pathways coded: {S['n_pathways']}",
f"- Observed denials: 0 (no case-level refusal evidence located)", "",
"## Endpoint results (main work pathway per jurisdiction)"]
for k, v in S["dss"].items(): L.append(f"- DSS {k}: {', '.join(v) or '—'}")
for k, v in S["hd"].items(): L.append(f"- HD_NAMED {k}: {', '.join(v) or '—'}")
for k, v in S["post"].items():
    if v: L.append(f"- POST_TREATMENT_RISK {k}: {', '.join(v)}")
L += ["", "## Per-jurisdiction summary", "", "| Jurisdiction | Queries | Sources | Best tier | DSS | HD | Unresolved reason / note |", "|---|---|---|---|---|---|---|"]
for r in js: L.append(f"| {r['jurisdiction_id']} | {r['n_queries']} | {r['n_sources_opened']} | {r['best_source_tier']} | {r['dss_status']} | {r['hd_named_status']} | {r['unresolved_reason'] or r['notes'].split(';')[0]} |")
L += ["", "## Key adjudications",
"- **Russia (HD confirmed).** MoH Order 1079n of 19.11.2021 (in force 01.03.2022–01.03.2028), appendix 'Перечень инфекционных заболеваний, представляющих опасность для окружающих', item 2 'А30 лепра (болезнь Гансена)'. Official publication PDF (publication.pravo.gov.ru) is a scan without a text layer; page 9 was rendered (01_raw_search_logs/B7/derived/RUS_1079n_p-09.png) and read visually; identical wording verified in the Garant consolidated appendix text. Garant shows original item 5 (COVID-19) repealed from 01.03.2022 by Order 94n — not coded. 115-FZ art. 7(1)(13): TRP refused/annulled for listed diseases. No stage/treatment distinction stated → risk_status no_treatment_distinction_named_condition. Predecessor Order 384n (2015) list (pre-rebuild snapshot re-read) also named leprosy — coded as recovered_historical.",
"- **Croatia.** New MoH Decision NN 79/2026: visa-regime TCNs extending temporary residence must exclude active TB, S. typhi/paratyphi carriage, HIV, HBV, HCV; positives referred for treatment (no refusal consequence stated). Leprosy not listed. HZJZ notice of one imported leprosy case is epidemiological, not a migration rule and not a denial case.",
"- **Hungary.** 32/2007 EüM decree (in force) annex lists TB, HIV, lues, typhoid/paratyphoid carriage, hepatitis B; Act XC of 2023 §226(1)(c) refusal/withdrawal only if the person also does not submit to mandatory care (coded mentioned_conditional for active/on-treatment). Decree 114/2007 and Act II of 2007 time states are historical.",
"- **Malta.** IDCU 2026 rules: chest X-ray by TB-risk country of birth/residence; HBsAg for certain jobs; Cap. 217 art. 5(2)(b) mental disorder. Leprosy appears only in Cap. 36 art. 10(1) (domestic notifiable-disease list for arts. 5–9), not a migration criterion → HD not_established.",
"- **Moldova.** MFA page requires a certificate of absence of HIV/AIDS plus a 'standard medical certificate' whose content (MoH order on migrant examination) could not be retrieved → DSS positive, HD cannot_determine.",
"- **Czech Republic.** Decree 274/2004 (TB, syphilis) repealed 18.12.2015; current 'doklad o bezinfekčnosti' only if an MoH measure exists or on suspicion → unresolved.",
"- **Greece.** Law 5038/2023 art. 8 generic (WHO/EU diseases; exams non-systematic; post-entry illness protected). 2010/2012 circulars under repealed law 3386/2005 required chest X-ray + Mantoux — historical/current conflict unresolved.",
"- **Generic-only or delegated lists (unresolved):** Albania, Andorra, Bulgaria (MoH criteria), Bosnia and Herzegovina, North Macedonia, Portugal, Slovakia (§32(10) medical report), Poland (Act art. 36 delegates a refusal-of-entry disease list to MoH regulation Dz.U. 2015 poz. 1501 — not retrievable), Kosovo. Generic wording coded GENERIC_FITNESS only.",
"- **documented_absence (medium confidence):** Spain (fixed IHR-2005 certificate wording names no disease), Italy and San Marino (official document checklists contain no medical certificate), Serbia (MUP list: health insurance only).",
"- **Insufficient access (unresolved):** Belarus (MoH list PDF timed out), Montenegro (gov.me/wapi timed out), Romania (IGI/OUG 403), Slovenia (ZTuj-2 not rendered), Ukraine (law text timed out), Vatican (no labour-migration pathway identified).",
"", "## Time-budget extensions", "- " + "\n- ".join(f"{r['jurisdiction_id']}: {r['notes'].split(';')[0]}" for r in js if r['notes'].startswith('extended')),
"", "## Documents opened (saved)", "See SOURCE_REGISTER.csv (local_path, URL, retrieved_utc, bytes, sha256). Pre-rebuild snapshots copied and re-read: MT_Cap36_pdf, RU_MoH384n_garant (original retrieval times kept).",
"HTTP 4xx/5xx error pages were not retained as sources (recorded in 01_raw_search_logs/B7/fetch_ledger.jsonl).",
"", "## Inaccessible sources (attempted, not saved)", "", "| ISO | short | HTTP | error | URL |", "|---|---|---|---|---|"]
L += [f"| {x.split('|')[0]} | {x.split('|')[1]} | {x.split('|')[2]} | {x.split('|')[3].strip()} | {x.split('|',4)[4].strip()} |" for x in inacc]
L += ["", "## Files", "- 01_raw_search_logs/B7: raw/ (per-query hit lists), search_staging.jsonl, fetch_ledger.jsonl, text/ (text extractions), derived/ (renders, raw pdftotext), tools/ (fetch, coding, build scripts), WORKING_NOTES.md",
"- 02_primary_sources/B7: unmodified source files", "- 03_extracted_evidence/B7: ten schema tables + this report", "", "Validator: `python3 scoping-review-hansens-disease/pgph_rebuild/scripts/validate_batch.py B7`."]
(OUT / "BATCH_REPORT.md").write_text("\n".join(L) + "\n"); print(len(L))
